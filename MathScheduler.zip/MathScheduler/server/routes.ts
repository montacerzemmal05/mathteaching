import { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertLearningSegmentSchema, insertResourceSchema, insertLessonSchema } from "@shared/schema";

export function registerRoutes(app: Express) {
  // Learning Segments
  app.get("/api/segments/:level", async (req, res) => {
    const segments = await storage.getLearningSegments(req.params.level);
    res.json(segments);
  });

  app.post("/api/segments", async (req, res) => {
    const parsed = insertLearningSegmentSchema.parse(req.body);
    const segment = await storage.createLearningSegment(parsed);
    res.json(segment);
  });

  // Resources
  app.get("/api/resources/:segmentId", async (req, res) => {
    const resources = await storage.getResources(parseInt(req.params.segmentId));
    res.json(resources);
  });

  app.post("/api/resources", async (req, res) => {
    const parsed = insertResourceSchema.parse(req.body);
    const resource = await storage.createResource(parsed);
    res.json(resource);
  });

  // Lessons
  app.get("/api/lessons/:level?", async (req, res) => {
    const level = req.params.level;
    const lessons = await storage.getLessons(level);
    res.json(lessons);
  });

  app.post("/api/lessons", async (req, res) => {
    const parsed = insertLessonSchema.parse(req.body);
    const lesson = await storage.createLesson(parsed);
    res.json(lesson);
  });

  app.patch("/api/lessons/:id", async (req, res) => {
    const parsed = insertLessonSchema.partial().parse(req.body);
    const lesson = await storage.updateLesson(parseInt(req.params.id), parsed);
    res.json(lesson);
  });

  app.delete("/api/lessons/:id", async (req, res) => {
    await storage.deleteLesson(parseInt(req.params.id));
    res.status(204).end();
  });

  return createServer(app);
}