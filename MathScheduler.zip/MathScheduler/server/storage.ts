import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { eq } from "drizzle-orm";
import { 
  LearningSegment, InsertLearningSegment,
  Resource, InsertResource,
  Lesson, InsertLesson,
  learningSegments,
  resources,
  lessons
} from "@shared/schema";

const queryClient = postgres(process.env.DATABASE_URL!);
const db = drizzle(queryClient);

export interface IStorage {
  // Learning Segments
  getLearningSegments(level: string): Promise<LearningSegment[]>;
  createLearningSegment(segment: InsertLearningSegment): Promise<LearningSegment>;

  // Resources
  getResources(segmentId: number): Promise<Resource[]>;
  createResource(resource: InsertResource): Promise<Resource>;

  // Lessons
  getLessons(level?: string): Promise<Lesson[]>;
  createLesson(lesson: InsertLesson): Promise<Lesson>;
  updateLesson(id: number, lesson: Partial<InsertLesson>): Promise<Lesson>;
  deleteLesson(id: number): Promise<void>;
}

export class PostgresStorage implements IStorage {
  async getLearningSegments(level: string): Promise<LearningSegment[]> {
    return await db.select().from(learningSegments).where(eq(learningSegments.level, level as any));
  }

  async createLearningSegment(segment: InsertLearningSegment): Promise<LearningSegment> {
    const [newSegment] = await db.insert(learningSegments).values(segment).returning();
    return newSegment;
  }

  async getResources(segmentId: number): Promise<Resource[]> {
    return await db.select().from(resources).where(eq(resources.segmentId, segmentId));
  }

  async createResource(resource: InsertResource): Promise<Resource> {
    const [newResource] = await db.insert(resources).values(resource).returning();
    return newResource;
  }

  async getLessons(level?: string): Promise<Lesson[]> {
    if (level) {
      return await db.select().from(lessons).where(eq(lessons.level, level as any));
    }
    return await db.select().from(lessons);
  }

  async createLesson(lesson: InsertLesson): Promise<Lesson> {
    const [newLesson] = await db.insert(lessons).values(lesson).returning();
    return newLesson;
  }

  async updateLesson(id: number, lesson: Partial<InsertLesson>): Promise<Lesson> {
    const [updatedLesson] = await db
      .update(lessons)
      .set(lesson)
      .where(eq(lessons.id, id))
      .returning();

    if (!updatedLesson) {
      throw new Error("Lesson not found");
    }

    return updatedLesson;
  }

  async deleteLesson(id: number): Promise<void> {
    await db.delete(lessons).where(eq(lessons.id, id));
  }
}

export const storage = new PostgresStorage();