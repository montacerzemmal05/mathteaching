import { pgTable, text, serial, integer, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Educational levels
export const levels = ["أولى متوسط", "ثانية متوسط", "ثالثة متوسط", "رابعة متوسط"] as const;
export type Level = typeof levels[number];

// Lesson types
export const lessonTypes = [
  "مورد معرفي",
  "مورد منهجي", 
  "اعمال موجهة",
  "استدراك",
  "معالجة بيداغوجية",
  "تقويم",
  "تصحيح وضعية الانطلاق",
  "اجراء فرض",
  "تصحيح فرض",
  "اجراء اختبار",
  "تصحيح اختبار"
] as const;
export type LessonType = typeof lessonTypes[number];

// Learning segments table
export const learningSegments = pgTable("learning_segments", {
  id: serial("id").primaryKey(),
  level: text("level", { enum: levels }).notNull(),
  title: text("title").notNull(),
});

// Resources table 
export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  segmentId: integer("segment_id").notNull(),
  title: text("title").notNull(),
  type: text("type", { enum: ["معرفي", "منهجي"] }).notNull()
});

// Lessons table
export const lessons = pgTable("lessons", {
  id: serial("id").primaryKey(),
  dayOfWeek: integer("day_of_week").notNull(), // 0-4 for Sun-Thu
  periodNumber: integer("period_number").notNull(), // 1-7
  type: text("type", { enum: lessonTypes }).notNull(),
  level: text("level", { enum: levels }).notNull(),
  
  // For knowledge/methodology lessons
  segmentId: integer("segment_id"),
  resourceId: integer("resource_id"),
  prepare: text("prepare"),
  learningActivity: text("learning_activity"),
  summary: text("summary"), 
  practice: text("practice"),
  reinforcement: text("reinforcement"),

  // For other lesson types
  topic: text("topic"),
});

// Insert schemas
export const insertLearningSegmentSchema = createInsertSchema(learningSegments).omit({ id: true });
export const insertResourceSchema = createInsertSchema(resources).omit({ id: true });
export const insertLessonSchema = createInsertSchema(lessons).omit({ id: true });

// Types
export type LearningSegment = typeof learningSegments.$inferSelect;
export type Resource = typeof resources.$inferSelect;
export type Lesson = typeof lessons.$inferSelect;
export type InsertLearningSegment = z.infer<typeof insertLearningSegmentSchema>;
export type InsertResource = z.infer<typeof insertResourceSchema>;
export type InsertLesson = z.infer<typeof insertLessonSchema>;
