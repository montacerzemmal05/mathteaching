import { levels, lessonTypes } from "@shared/schema";

// Make sure levels are in the correct order
export const LEVELS = [
  "أولى متوسط",
  "ثانية متوسط",
  "ثالثة متوسط",
  "رابعة متوسط"
] as const;

export const LESSON_TYPES = lessonTypes;

export const STORAGE_KEYS = {
  LEVEL: "selected_level",
  THEME: "color_theme"
} as const;

export const DEFAULT_LEVEL = LEVELS[0];