export interface TimeSlot {
  id: number;
  start: string;
  end: string;
}

export const MORNING_SLOTS: TimeSlot[] = [
  { id: 1, start: "08:00", end: "09:00" },
  { id: 2, start: "09:00", end: "10:00" },
  { id: 3, start: "10:00", end: "11:00" },
  { id: 4, start: "11:00", end: "12:00" }
];

export const AFTERNOON_SLOTS: TimeSlot[] = [
  { id: 5, start: "13:30", end: "14:30" },
  { id: 6, start: "14:30", end: "15:30" },
  { id: 7, start: "15:30", end: "16:30" }
];

export const ALL_SLOTS = [...MORNING_SLOTS, ...AFTERNOON_SLOTS];

export const DAYS = [
  "الأحد",
  "الإثنين",
  "الثلاثاء",
  "الأربعاء",
  "الخميس"
] as const;

export type Day = typeof DAYS[number];
