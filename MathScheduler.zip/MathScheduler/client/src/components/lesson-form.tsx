import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { insertLessonSchema } from "@shared/schema";
import { LESSON_TYPES } from "@/lib/constants";
import { apiRequest } from "@/lib/queryClient";

interface LessonFormProps {
  level: string;
  segments?: any[];
  defaultValues?: any;
}

export default function LessonForm({ level, segments = [], defaultValues }: LessonFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm({
    resolver: zodResolver(insertLessonSchema),
    defaultValues: {
      level,
      ...defaultValues
    }
  });

  const createLessonMutation = useMutation({
    mutationFn: async (values: any) => {
      const res = await apiRequest("POST", "/api/lessons", values);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lessons"] });
      toast({ description: "تم إضافة الدرس بنجاح" });
    }
  });

  const onSubmit = (values: any) => {
    createLessonMutation.mutate(values);
  };

  const showResourceFields = form.watch("type") === "مورد معرفي" || form.watch("type") === "مورد منهجي";

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="type"
          render={({ field }) => (
            <FormItem>
              <FormLabel>نوع الحصة</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر نوع الحصة" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {LESSON_TYPES.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </FormItem>
          )}
        />

        {showResourceFields ? (
          <>
            <FormField
              control={form.control}
              name="segmentId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>المقطع التعلمي</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value?.toString()}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر المقطع" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {segments.map((segment) => (
                        <SelectItem key={segment.id} value={segment.id.toString()}>
                          {segment.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="prepare"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>استعد</FormLabel>
                  <FormControl>
                    <Textarea {...field} />
                  </FormControl>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="learningActivity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>الوضعية التعلمية</FormLabel>
                  <FormControl>
                    <Textarea {...field} />
                  </FormControl>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="summary"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>الحوصلة</FormLabel>
                  <FormControl>
                    <Textarea {...field} />
                  </FormControl>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="practice"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>الاستثمار</FormLabel>
                  <FormControl>
                    <Textarea {...field} />
                  </FormControl>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="reinforcement"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>اعادة الاستثمار</FormLabel>
                  <FormControl>
                    <Textarea {...field} />
                  </FormControl>
                </FormItem>
              )}
            />
          </>
        ) : (
          <FormField
            control={form.control}
            name="topic"
            render={({ field }) => (
              <FormItem>
                <FormLabel>موضوع الحصة</FormLabel>
                <FormControl>
                  <Input {...field} />
                </FormControl>
              </FormItem>
            )}
          />
        )}

        <Button type="submit" className="w-full">
          حفظ
        </Button>
      </form>
    </Form>
  );
}
