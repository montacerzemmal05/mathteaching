import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { insertLearningSegmentSchema, type Level } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import type { InsertLearningSegment } from "@shared/schema";

interface CurriculumFormProps {
  level: Level;
}

export default function CurriculumForm({ level }: CurriculumFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertLearningSegment>({
    resolver: zodResolver(insertLearningSegmentSchema),
    defaultValues: {
      level,
      title: ""
    }
  });

  const createSegmentMutation = useMutation({
    mutationFn: async (values: InsertLearningSegment) => {
      const res = await apiRequest("POST", "/api/segments", values);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/segments", level] });
      toast({ description: "تم إضافة المقطع بنجاح" });
    }
  });

  const onSubmit = (values: InsertLearningSegment) => {
    createSegmentMutation.mutate(values);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>عنوان المقطع</FormLabel>
              <FormControl>
                <Input {...field} />
              </FormControl>
            </FormItem>
          )}
        />

        <Button type="submit" className="w-full">
          حفظ
        </Button>
      </form>
    </Form>
  );
}