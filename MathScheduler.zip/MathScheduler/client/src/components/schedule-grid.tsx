import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import LessonForm from "./lesson-form";
import { ALL_SLOTS, DAYS } from "@/lib/types";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, X } from "lucide-react";
import type { Lesson } from "@shared/schema";
import type { Day } from "@/lib/types";

interface ScheduleGridProps {
  lessons: Lesson[];
  level: string;
}

export default function ScheduleGrid({ lessons, level }: ScheduleGridProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const deleteLessonMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/lessons/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lessons", level] });
      toast({ description: "تم حذف الدرس بنجاح" });
    }
  });

  const getLessonForSlot = (day: Day, period: number) => {
    return lessons.find(
      (l) => l.dayOfWeek === DAYS.indexOf(day) && l.periodNumber === period
    );
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr>
            <th className="border p-2">الحصة</th>
            {DAYS.map((day) => (
              <th key={day} className="border p-2">
                {day}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {ALL_SLOTS.map((slot) => (
            <tr key={slot.id}>
              <td className="border p-2 whitespace-nowrap">
                {slot.start} - {slot.end}
              </td>
              {DAYS.map((day) => {
                const lesson = getLessonForSlot(day, slot.id);

                return (
                  <td key={day} className="border p-2 min-w-[200px]">
                    {lesson ? (
                      <div className="flex items-center justify-between">
                        <span>{lesson.type}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteLessonMutation.mutate(lesson.id)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ) : (
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full">
                            <Plus className="h-4 w-4 ml-2" />
                            إضافة درس
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <LessonForm
                            level={level}
                            defaultValues={{
                              dayOfWeek: DAYS.indexOf(day),
                              periodNumber: slot.id
                            }}
                          />
                        </DialogContent>
                      </Dialog>
                    )}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}