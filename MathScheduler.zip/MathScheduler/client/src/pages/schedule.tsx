import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import ScheduleGrid from "@/components/schedule-grid";
import { LEVELS, STORAGE_KEYS } from "@/lib/constants";
import { getLocalStorage, setLocalStorage } from "@/lib/utils";
import type { Level } from "@shared/schema";

export default function Schedule() {
  const [selectedLevel, setSelectedLevel] = useState<Level>(
    () => getLocalStorage<Level>(STORAGE_KEYS.LEVEL, "أولى متوسط")
  );

  const { data: lessons = [] } = useQuery({
    queryKey: ["/api/lessons", selectedLevel]
  });

  const handleLevelChange = (value: Level) => {
    setSelectedLevel(value);
    setLocalStorage(STORAGE_KEYS.LEVEL, value);
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>الجدول الأسبوعي - {selectedLevel}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-end mb-4">
            <Select value={selectedLevel} onValueChange={handleLevelChange}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="اختر المستوى" />
              </SelectTrigger>
              <SelectContent>
                {LEVELS.map((level) => (
                  <SelectItem key={level} value={level}>
                    {level}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <ScheduleGrid lessons={lessons} level={selectedLevel} />
        </CardContent>
      </Card>
    </div>
  );
}