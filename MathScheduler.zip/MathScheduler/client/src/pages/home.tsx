import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CalendarDays, BookOpen, FileText } from "lucide-react";
import { LEVELS, STORAGE_KEYS } from "@/lib/constants";
import { getLocalStorage, setLocalStorage } from "@/lib/utils";

export default function Home() {
  const [, setLocation] = useLocation();
  const [selectedLevel, setSelectedLevel] = useState<string>(
    () => getLocalStorage(STORAGE_KEYS.LEVEL, "")
  );

  const handleLevelChange = (value: string) => {
    setSelectedLevel(value);
    setLocalStorage(STORAGE_KEYS.LEVEL, value);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted p-6">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold">تطبيق إدارة الدروس</h1>
          <p className="text-muted-foreground text-lg">نظّم جدولك الدراسي وخطط دروسك بسهولة</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>اختر المستوى الدراسي</CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={selectedLevel} onValueChange={handleLevelChange}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="اختر المستوى" />
              </SelectTrigger>
              <SelectContent>
                {LEVELS.map((level) => (
                  <SelectItem key={level} value={level}>
                    {level}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {selectedLevel && (
          <div className="grid md:grid-cols-3 gap-6">
            <Card 
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setLocation("/schedule")}
            >
              <CardHeader>
                <CalendarDays className="h-10 w-10 text-primary mb-2" />
                <CardTitle>الجدول الأسبوعي</CardTitle>
                <CardDescription>تنظيم الحصص الدراسية</CardDescription>
              </CardHeader>
            </Card>

            <Card 
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setLocation("/lessons")}
            >
              <CardHeader>
                <BookOpen className="h-10 w-10 text-primary mb-2" />
                <CardTitle>الدروس</CardTitle>
                <CardDescription>إدارة الدروس والمقاطع التعلمية</CardDescription>
              </CardHeader>
            </Card>

            <Card 
              className="cursor-pointer hover:shadow-lg transition-shadow"
              onClick={() => setLocation("/documents")}
            >
              <CardHeader>
                <FileText className="h-10 w-10 text-primary mb-2" />
                <CardTitle>وثائق الأستاذ</CardTitle>
                <CardDescription>المستندات والوثائق المرجعية</CardDescription>
              </CardHeader>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}