import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Plus, Book, GraduationCap, Calendar } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import CurriculumForm from "@/components/curriculum-form";
import { DEFAULT_LEVEL, LEVELS, STORAGE_KEYS } from "@/lib/constants";
import { getLocalStorage, setLocalStorage } from "@/lib/utils";

export default function Curriculum() {
  const [selectedLevel, setSelectedLevel] = useState<string>(
    () => getLocalStorage(STORAGE_KEYS.LEVEL, DEFAULT_LEVEL)
  );

  const { data: segments = [] } = useQuery({
    queryKey: ["/api/segments", selectedLevel]
  });

  const handleLevelChange = (value: string) => {
    setSelectedLevel(value);
    setLocalStorage(STORAGE_KEYS.LEVEL, value);
  };

  const documents = [
    { title: "كتاب التلميذ", icon: Book },
    { title: "دليل الأستاذ", icon: FileText },
    { title: "مخطط التعلمات الوزاري", icon: GraduationCap },
    { title: "التدرج السنوي", icon: Calendar }
  ];

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* وثائق الأستاذ */}
      <Card>
        <CardHeader>
          <CardTitle>وثائق الأستاذ</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            {documents.map((doc) => (
              <Card key={doc.title} className="hover:bg-muted/50 transition-colors">
                <CardHeader className="flex flex-row items-center gap-4">
                  <doc.icon className="h-8 w-8 text-primary" />
                  <CardTitle className="text-lg">{doc.title}</CardTitle>
                </CardHeader>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* المقاطع التعلمية */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>المقاطع التعلمية</CardTitle>
          <div className="flex gap-4">
            <Select value={selectedLevel} onValueChange={handleLevelChange}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="اختر المستوى" />
              </SelectTrigger>
              <SelectContent>
                {LEVELS.map((level) => (
                  <SelectItem key={level} value={level}>
                    {level}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Dialog>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="ml-2 h-4 w-4" />
                  مقطع جديد
                </Button>
              </DialogTrigger>
              <DialogContent>
                <CurriculumForm level={selectedLevel} />
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            {segments.map((segment: any) => (
              <Card key={segment.id}>
                <CardHeader>
                  <CardTitle>{segment.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  {/* TODO: Add resources list */}
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}