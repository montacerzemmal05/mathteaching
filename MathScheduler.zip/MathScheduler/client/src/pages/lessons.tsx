import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, Plus, Book, GraduationCap, Calendar } from "lucide-react";
import LessonForm from "@/components/lesson-form";
import CurriculumForm from "@/components/curriculum-form";
import { STORAGE_KEYS } from "@/lib/constants";
import { getLocalStorage } from "@/lib/utils";
import type { Level } from "@shared/schema";

export default function Lessons() {
  // Get the selected level from localStorage
  const selectedLevel = getLocalStorage<Level>(STORAGE_KEYS.LEVEL, "أولى متوسط");

  const { data: segments = [] } = useQuery({
    queryKey: ["/api/segments", selectedLevel]
  });

  const documents = [
    { title: "كتاب التلميذ", icon: Book },
    { title: "دليل الأستاذ", icon: FileText },
    { title: "مخطط التعلمات الوزاري", icon: GraduationCap },
    { title: "التدرج السنوي", icon: Calendar }
  ];

  return (
    <div className="container mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>وثائق الأستاذ - {selectedLevel}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            {documents.map((doc) => (
              <Card key={doc.title} className="hover:bg-muted/50 transition-colors">
                <CardHeader className="flex flex-row items-center gap-4">
                  <doc.icon className="h-8 w-8 text-primary" />
                  <CardTitle className="text-lg">{doc.title}</CardTitle>
                </CardHeader>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="lessons">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="lessons">الدروس</TabsTrigger>
          <TabsTrigger value="segments">المقاطع التعلمية</TabsTrigger>
        </TabsList>

        <TabsContent value="lessons">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>إدارة الدروس - {selectedLevel}</CardTitle>
              <Dialog>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="ml-2 h-4 w-4" />
                    درس جديد
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <LessonForm segments={segments} level={selectedLevel} />
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {/* TODO: Add lesson list component filtered by selectedLevel */}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="segments">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>المقاطع التعلمية - {selectedLevel}</CardTitle>
              <Dialog>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="ml-2 h-4 w-4" />
                    مقطع جديد
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <CurriculumForm level={selectedLevel} />
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                {segments.map((segment: any) => (
                  <Card key={segment.id}>
                    <CardHeader>
                      <CardTitle>{segment.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {/* TODO: Add resources list filtered by selectedLevel */}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}